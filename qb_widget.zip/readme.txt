=== Quote of the Day by Quotations Book ===
Contributors: quotationsbook.com
Donate link: http://quotationsbook.com/services/
Tags: quote, quote of the day, quotes, quotations, famous quotes, qb, widget, sidebar, quotationsbook

Requires at least: 3.0.1
Tested up to: 3.8.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin lets you add a Quote of the Day widget to your WordPress page. 

== Description ==
This plugin lets you add a Quote of the Day widget to your WordPress page. Famous quotations will automatically appear on your page, every day!

The quotes come from [Quotations Book](http://quotationsbook.com) - one of the best quotation sites on the web, and this is the official Wordpress plugin for their quotes of the day service, which has been running for the last 8 years. You can expect a fresh Quote of the Day that educates, entertains and informs your audience.

= Features =
* Widget allows you to place a Quote of the Day sidebar on your page
* Widget adapts to the theme of your page

= For more information =

To learn more about the plugin, visit [Quotations Book - Quotes of the Day Service](http://quotationsbook.com/services/) page.

== Installation ==
1. Upload `qb_widget.php` to the `/wp-content/plugins/` directory.
2. Activate the plugin through the `Plugins` menu in WordPress.
3. Go to `Appearance`,  `Widgets` in WordPress.
4. Drag the `QB Widget` to the sidebar, for example the `Main Widget Area` or the `Secondary Widget Area`.

== Frequently Asked Questions ==

= What versions of WordPress does this work with? =
We tested with 3.6.1,  3.7.1, and 3.8.1 but it probably works with other versions (3.x or greater).  

Let us know in the "Compatibility" poll if it does work with a particular version, and let us know (via the Support tab) if there are any issues with anything newer than 3.7.1. Thanks!

== Screenshots ==

1. Configuring the widget on the admin screen (Appearance, Widgets).
2. Screenshot of the wordpress page with a single Quote Of The Day widget.

== Changelog ==
= 1.0 =
* Tested and launched plugin.
